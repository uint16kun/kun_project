#ifndef speed_bl_h
#define speed_bl_h
#include "Arduino.h"
void Encoder_init(void);
IRAM_ATTR void  timer0_event(void);
void timer0_init(void);
IRAM_ATTR void Encoder_1_A_inter(void);
IRAM_ATTR void Encoder_2_A_inter(void);
int Encoder_get_num(uint8_t Encoder_which);
#endif