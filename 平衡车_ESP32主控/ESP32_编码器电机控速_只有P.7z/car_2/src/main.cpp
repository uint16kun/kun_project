#include <Arduino.h>
#include "../lib/motor_bl/motor_bl.h"
#include "../lib/speed_bl/speed_bl.h"
int num;
void setup() 
{
  Serial.begin(115200);
  // Serial2.begin(115200);
  motor_init();
  Encoder_init();
  timer0_init();

}

void loop() 
{
  
  Serial.println(Encoder_1_change);
}