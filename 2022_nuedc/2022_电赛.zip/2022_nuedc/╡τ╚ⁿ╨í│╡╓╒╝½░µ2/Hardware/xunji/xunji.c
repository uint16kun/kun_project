#include "xunji.h"
#include "delay.h"

extern int VL,VR,Sig;
unsigned int flag=0,SUM=0,Pre=0,stop=0;
int ChaZhi=0,k=1,x=20;
void Xunji_Init(void)
{
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN0 | GPIO_PIN1|GPIO_PIN2 | GPIO_PIN3|GPIO_PIN4);
	GPIO_setAsOutputPin(GPIO_PORT_P6, GPIO_PIN4);
	GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN4);
}
void xunji()
{
//	ChaZhi=VL-VR;
//	if(ChaZhi<0)
//	{
//		ChaZhi=-ChaZhi;
//	}
	if(xunji1==0&&xunji2==0&&xunji3==1&&xunji4==0&&xunji5==0)
	{
		if(flag==1)
		{
			Car_Right();
			delay_ms(100);
		}
		else if(flag==2)
		{
			Car_Left();
			delay_ms(100);
		}
		else
		{
		
		}

			Car_Go();

	}
	else if(xunji1==0&&xunji2==1&&xunji3==0&&xunji4==0&&xunji5==0)
	{
		Car_Left();
		flag=1;
	}
	else if(xunji1==1&&xunji2==0&&xunji3==0&&xunji4==0&&xunji5==0)
	{
		Car_BigLeft();
		flag=1;
	}
	else if(xunji1==0&&xunji2==0&&xunji3==0&&xunji4==1&&xunji5==0)
	{
		
		Car_Right();
		flag=2;
	}
	else if(xunji1==0&&xunji2==0&&xunji3==0&&xunji4==0&&xunji5==1)
	{
		Car_BigRight();
		flag=2;
	}
	else if(xunji1==0&&xunji2==0&&xunji3==0&&xunji4==0&&xunji5==0)
	{
		if(flag==1)
		{
			Car_BigLeft();
		}
		else if(flag==2)
		{
			Car_BigRight();
		}
//		else if(flag==3)
//		{
//			Car_BigRight();
//		}
//		else if(flag==4)
//		{
//			Car_BigRight();
//		}
		else
		{
			Car_Go();
		}
	}
	else if((xunji1==1&&xunji2==0&&xunji3==1&&xunji4==0&&xunji5==0)||(xunji1==1&&xunji2==1&&xunji3==0&&xunji4==0&&xunji5==0)||(xunji1==1&&xunji2==1&&xunji3==1&&xunji4==0&&xunji5==0))
	{
		Car_Go();
		delay_ms(800);
		delay_ms(500);
	}
//	else if((xunji1==0&&xunji2==1&&xunji3==1&&xunji4==0&&xunji5==0)||(xunji1==1&&xunji2==0&&xunji3==1&&xunji4==0&&xunji5==0)||(xunji1==1&&xunji2==1&&xunji3==1&&xunji4==1&&xunji5==0))
//	{
//		Car_BigLeft();
//		delay_ms(800);
//		delay_ms(800);
//	}
	else if(/*(xunji1==0&&xunji2==1&&xunji3==1&&xunji4==0&&xunji5==0)||*/(xunji1==1&&xunji2==1&&xunji3==1&&xunji4==1&&xunji5==1)||(xunji1==0&&xunji2==1&&xunji3==1&&xunji4==1&&xunji5==0)||(xunji1==0&&xunji2==0&&xunji3==1&&xunji4==1&&xunji5==0))
	{
		
	}
	else
	{
		Car_Go();
	}
}