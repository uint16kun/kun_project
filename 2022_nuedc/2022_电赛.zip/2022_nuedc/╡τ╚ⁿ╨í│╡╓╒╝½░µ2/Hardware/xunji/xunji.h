#ifndef __XUNJI_H
#define __XUNJI_H

#include <stdint.h>
#include <stdbool.h>
#include <driverlib.h>
#include "moter.h"

void Xunji_Init(void);
void xunji();

// λ������
#define xunji1 BITBAND_PERI(P4IN, 0)
#define xunji2 BITBAND_PERI(P4IN, 1)
#define xunji3 BITBAND_PERI(P4IN, 2)
#define xunji4 BITBAND_PERI(P4IN, 3)
#define xunji5 BITBAND_PERI(P4IN, 4)

#endif
