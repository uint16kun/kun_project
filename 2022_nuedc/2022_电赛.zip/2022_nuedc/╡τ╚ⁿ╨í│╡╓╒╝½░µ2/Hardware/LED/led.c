#include <led.h>

/*****************************************************************
*Function: LED_Init(void)
*Description:LED��ʼ��
*Input:��
*Output:��
*Return:��
*Others:��
*Data:2021/09/14
*****************************************************************/
void LED_Init(void)
{
	/*LED1����*/
	GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0);
	/*LED2����*/
  GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0);
  GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN1);
  GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN2);
	
	LED1_OFF;
	LED2_BLUE_OFF;
	LED2_GREEN_OFF;
	LED2_RED_OFF;
}
void LED_Bright(int mode)
{
	if(mode==1)
	{
		LED1_ON;
		LED2_BLUE_OFF;
		LED2_GREEN_OFF;
		LED2_RED_OFF;
	}
	else if(mode==2)
	{
		LED2_BLUE_ON;
		LED1_OFF;
		LED2_GREEN_OFF;
		LED2_RED_OFF;
	}
	else if(mode==3)
	{
		LED1_OFF;
		LED2_BLUE_OFF;
		LED2_RED_OFF;
		LED2_GREEN_ON;
	}
	else if(mode==4)
	{
		LED2_RED_ON;
		LED1_OFF;
		LED2_BLUE_OFF;
		LED2_GREEN_OFF;
	}
	else
	{
	
	}
}

