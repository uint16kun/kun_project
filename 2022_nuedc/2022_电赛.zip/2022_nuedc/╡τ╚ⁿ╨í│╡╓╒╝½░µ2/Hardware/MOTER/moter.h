#ifndef __MOTER_H
#define __MOTER_H

#include <stdint.h>
#include <stdbool.h>
#include <driverlib.h>

#include "timer.h"


// λ������

#define Ain1 BITBAND_PERI(P8OUT,4)
#define Ain2 BITBAND_PERI(P8OUT,5)
#define Bin1 BITBAND_PERI(P8OUT,6)
#define Bin2 BITBAND_PERI(P8OUT,7)


extern int VL;
extern int VR;
void moter_Init(void);
int GFP_abs(int p);
void Load(int moto1,int moto2);
void Car_Go(void);
void Car_Right(void);
void Car_Left(void);
void Car_Back(void);
void Car_BigRight(void);
void Car_BigLeft(void);

#endif

