#ifndef __USART_H
#define __USART_H

#include <driverlib.h>
#include <stdio.h> //1.61328125kb

#define USART_REC_LEN  			200  	//�����������ֽ��� 200

void uart_init(uint32_t baudRate);
void UART_NVIC_Init(void);
void EUSCIA0_IRQHandler(void);
void EUSCIA2_IRQHandler(void);
void uart_init1(uint32_t baudRate);
void UART_NVIC_Init1(void);
#endif

