#ifndef __EXTI_H
#define __EXTI_H 			   

#include <driverlib.h>

extern int encoder_L;
extern int encoder_R;

void EXTI_Init(void);

#endif

