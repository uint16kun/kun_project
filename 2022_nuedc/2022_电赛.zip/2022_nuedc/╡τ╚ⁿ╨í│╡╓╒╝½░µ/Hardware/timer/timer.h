#ifndef __TIMER_H	
#define __TIMER_H	 

#include <driverlib.h>

extern int encoder_L;
extern int encoder_R;

void TimA0_Init(uint16_t ccr0, uint16_t psc);
void TimA1_PWM_Init(uint16_t ccr0, uint16_t psc);

#endif

