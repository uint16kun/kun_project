#include "xunji.h"
unsigned int flag=0;
void Xunji_Init(void)
{
	GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4, GPIO_PIN0 | GPIO_PIN1|GPIO_PIN2 | GPIO_PIN3|GPIO_PIN4);
}
void xunji(void)
{
	if((xunji1==0)&&(xunji2==0)&&(xunji3==1)&&(xunji4==0)&&(xunji5==0))
	{
		if(flag==1)
		{
			Car_Right();
		}
		else if(flag==2)
		{
			Car_Left();
		}
		else
		{
		
		}
		Car_Go();
		flag=0;
	}
	else if((xunji1==0)&&(xunji2==1)&&(xunji3==0)&&(xunji4==0)&&(xunji5==0))
	{
		Car_Left();
		flag=1;
	}
	else if((xunji1==0)&&(xunji2==0)&&(xunji3==0)&&(xunji4==1)&&(xunji5==0))
	{
		Car_Right();
		flag=2;
	}
	else if((xunji1==1)&&(xunji2==0)&&(xunji3==0)&&(xunji4==0)&&(xunji5==0))
	{
		Car_BigLeft();
		flag=1;
	}
	else if((xunji1==0)&&(xunji2==0)&&(xunji3==0)&&(xunji4==0)&&(xunji5==1))
	{
		Car_BigRight();
		flag=2;
	}
	else if((xunji1==0)&&(xunji2==0)&&(xunji3==0)&&(xunji4==0)&&(xunji5==0))
	{
		if(flag==1)
		{
			Car_BigLeft();
		}
		else if(flag==2)
		{
			Car_BigRight();
		}
		else
		{
			Car_Go();
		}
	}
	//////////////////////////////////////////////////////////////////
	else
	{
		Car_Go();
	}
}
